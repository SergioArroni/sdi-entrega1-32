package com.uniovi.sdientrega132.repositories;

import com.uniovi.sdientrega132.entities.Log;
import org.springframework.data.repository.CrudRepository;

public interface LogsRepository extends CrudRepository<Log, Long> {

}
